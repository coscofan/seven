
var lang = new Array();

//attorn
lang['attorn_success'] = "Attorn success";

//catalog
lang["none"] = "none";
lang["save_success"] = "Save success";
lang["save_fail"] = "Save fail";
lang["confirm_to_delete"] = "Are you sure that you want to delete it?";
lang["delete_success"] = "Delete success";
lang["delete_fail"] = "Delete fail";

//item
lang["back_to_top"] = "Back to top";


//page/edite
lang["params"] = "Params";
lang["type"] = "Type";
lang["description"] = "Description";
lang["editormd_placeholder"] = "Supports Markdown.the left side to edite, the right Preview";
lang["json_fail"] = "JSON import failed";
lang["filed"] = "filed";


