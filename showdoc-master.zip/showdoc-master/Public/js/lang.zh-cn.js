
var lang = new Array();

//attorn
lang['attorn_success'] = "转让成功！";

//catalog
lang["none"] = "无";
lang["save_success"] = "保存成功！";
lang["save_fail"] = "保存失败！";
lang["confirm_to_delete"] = "确认删除吗？";
lang["delete_success"] = "删除成功！";
lang["delete_fail"] = "删除失败！";

//item
lang["back_to_top"] = "回到顶部";


//page/edite
lang["params"] = "参数名";
lang["type"] = "类型";
lang["description"] = "说明";
lang["editormd_placeholder"] = "本编辑器支持Markdown编辑，左边编写，右边预览";
lang["json_fail"] = "json导入失败";
lang["filed"] = "键";


