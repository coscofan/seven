
/*判断是否是移动设备*/
function isMobile(){
return navigator.userAgent.match(/iPhone|iPad|iPod|Android|android|BlackBerry|IEMobile/i) ? true : false; 
}


